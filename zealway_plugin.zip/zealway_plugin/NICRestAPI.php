<?php 

/*$url = "https://apitest.cybersource.com/pts/v2/payments";*/
/*
$url = "http://10.0.0.18:8089/zealway_plugingnew/helloworld";


$jsonArrya=array(
    "clientReferenceInformation" => array(
        "code" => "TC50171_3"
    ),
    "processingInformation" => array(
        "actionList" => array(
            "CONSUMER_AUTHENTICATION"
        )
    ),
    "paymentInformation" => array(
        "card" => array(
            "number" => "4000000000001091",
            "expirationMonth" => "12",
            "expirationYear" => "2023"
        )
    ),
    "orderInformation" => array(
        "amountDetails" => array(
            "totalAmount" => "100.00",
            "currency" => "usd"
        ),
        "billTo" => array(
            "firstName" => "John",
            "lastName" => "Smith",
            "address1" => "201 S. Division St._1",
            "address2" => "Suite 500",
            "locality" => "Foster City",
            "administrativeArea" => "CA",
            "postalCode" => "94404",
            "country" => "US",
            "email" => "accept@cybersource.com",
            "phoneNumber" => "6504327113"
        )
    ),
    "consumerAuthenticationInformation" => array(
        "requestorId" => "123123197675",
        "referenceId" => "CybsCruiseTester-8ac0b02f"
    )
);

$content =  json_encode($jsonArrya, true);
//echo $content;

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER,
        array("Content-type: application/json"));
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $content);

$json_response = curl_exec($curl);

$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);

if ( $status != 201 ) {
    die("Error: call to URL $url failed with status $status, response $json_response, curl_error " . curl_error($curl) . ", curl_errno " . curl_errno($curl));
}
curl_close($curl);

$response = json_decode($json_response, true);
echo $response; 
*/


$url = "http://localhost:8089/zealway_plugingnew/helloworld";
$response = file_get_contents($url);

/*<h2>$response</h2>*/

print_r($response);   
//print_r($response[1]["id"]) ;    // Dump all data of the Array
//echo $response[1]["id"];
//echo $response123;


/*
$re=CallAPI("POST","http://localhost:8089/zealway_plugingnew/helloworld",false);

function CallAPI($method, $url, $data = false)
{
    $curl = curl_init();

    switch ($method)
    {
        case "POST":
            curl_setopt($curl, CURLOPT_POST, 1);

            if ($data)
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            break;
        case "PUT":
            curl_setopt($curl, CURLOPT_PUT, 1);
            break;
        default:
            if ($data)
                $url = sprintf("%s?%s", $url, http_build_query($data));
    }

    // Optional Authentication:
    curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
   /* curl_setopt($curl, CURLOPT_USERPWD, "username:password");*/

   /* curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

    $result = curl_exec($curl);

    curl_close($curl);

    return $result;
}
*/

?>