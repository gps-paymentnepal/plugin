<!DOCTYPE html>
<html lang="en">
<head>
   <link rel="stylesheet" href="/wordpress/wp-content/plugins/sample_plugin/css/popup.css"/>
   <link rel="stylesheet1" href="/wordpress/wp-content/plugins/sample_plugin/js/popup_call.js"/>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

.button {
  border: none;
  color: white;
background-color: #008CBA;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>


<script type="text/javascript">
function createPopup(){
var popup = open("", "Popup", "width=300,height=200");
var txtOk = popup.document.createElement("TEXTAREA");
var aOk = popup.document.createElement("a");
aOk.innerHTML = "Click here";

popup.document.body.appendChild(txtOk);
popup.document.body.appendChild(aOk);
}



</script>

<script type="text/javascript">
  
$('#but').click(function() {
    $("#dialogForm").dialog("open");
});
    $("#dialogForm").dialog({
        modal: true,
        autoOpen: true,
        show: {effect: "blind", duration: 800}
    }); 
</script>

</head>
<body>

<form action="/wordpress/index.php/83-2/" method="post">
<table>
<thead>
<tr>
<th>Image</th>
<th>Item Name</th>
<th>Price</th>
<th>Quantity</th>
<th>Subtotal</th>
</tr>
</thead>
<tbody>
<tr>
<th><img src="/wordpress/wp-content/plugins/sample_plugin/images/pen1.jpg" width="60" height="80" style="vertical-align:middle"></th>
<th>Pen</th>
<th>10</th>
<th>2</th>
<th>20</th>
</tr>
<tr>
<th><img src="/wordpress/wp-content/plugins/sample_plugin/images/colorbox.jpg" width="60" height="80" style="vertical-align:middle"></th>
<th>Color Box</th>
<th>30</th>
<th>2</th>
<th>60</th>
</tr>
<tr>
<th><img src="/wordpress/wp-content/plugins/sample_plugin/images/schoolbag.jpg" width="60" height="80" style="vertical-align:middle"></th>
<th>School Bag</th>
<th>300</th>
<th>1</th>
<th>300</th>
</tr>
</tbody>
</table>

<p><label for="subtoal">Subtotal</label> <input name="subtotal" type="text" id="subtotal" value="380"></p>

<p><label for="total">Total</label> <input name="total" type="text" value="380" id="total"></p>
<textarea class="Box"></textarea>
<input type="submit" class="button">
<input type="submit" value="click" onclick="createPopup">
</form>
<div id="divPopup" onclick="createPopup();">Create popup</div>

<a class="trigger_popup_fricc">Click here to show the popup</a> <br><br>

<div class="hover_bkgr_fricc">
    <span class="helper"></span>
    <div>
        <div class="popupCloseButton">&times;</div>
        <p>Add any HTML content<br />inside the popup box!</p>
    </div>
</div>

<button type="button" id="but" >Open Popup</button> <br><br>

<div id="dialogForm">
    <form id="myform" method="post">
        Name:
        <input type="text"/><br/>
        Phone:
        <input type="text"/><br/>
        <button type="submit"> Submit </button>
    </form>
</div>

<button class="trigger">Click here to trigger the modal!</button>
<div class="modal">
    <div class="modal-content">
        <span class="close-button">×</span>
        <h1>Hello, I am a modal!</h1>
    </div>
</div>

</body>
</html>