<?php

function wc_auction_reports() {



	<!DOCTYPE html>
<html>
<head>
	
	 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

	 <script type="text/javascript">

    function restAPICall () {

    var dataPost = {
   "customer_name": document.getElementById("fname").value +' '+document.getElementById("lname").value,
   "invDate": document.getElementById("txt_invoiceDate").value,
   "invNo": document.getElementById("txt_invoiceNo").value,
   "billAddr1": document.getElementById("txt_billing_address1").value,
   "billAddr2": document.getElementById("txt_billing_address2").value,
   "billAddr3": document.getElementById("txt_billing_address3").value,
   "billAddrCity": document.getElementById("txt_billingCityName").value,
   "billAddrState": document.getElementById("txt_billingStateName").value,
   "billAddrCountry": document.getElementById("txt_billingCountryName").value,
   "billZip": document.getElementById("txt_pincode").value,
   "shipAddr1": document.getElementById("txt_shipping_address1").value,
   "shipAddr2": document.getElementById("txt_shipping_address2").value,
   "shipAddr3": document.getElementById("txt_shipping_address3").value,
   "shipCity": document.getElementById("txt_shippingCityName").value,
   "shipState": document.getElementById("txt_shippingStateName").value,
   "shipCountry": document.getElementById("txt_shippingCountryName").value,
   "shipZip": document.getElementById("txt_shipping_pincode").value,
   "customerEmail": document.getElementById("email_id").value,
   "customerWorkingNo": document.getElementById("phoneno").value,
   "customerHomeNo": document.getElementById("txt_homePhoneNo").value,
   "customerMobileNo": document.getElementById("txt_mobileNo").value,
   "totalAmount": document.getElementById("input_total").value
    };

    var dataString = JSON.stringify(dataPost);
      $.ajax({
        url:"/wordpress/wp-content/plugins/sample_plugin/restPost.php", //the page containing php script
        type: "POST", //request type
        data: {myData: dataString},
        success:function(result){
         alert(result);
       }
     });
 }
</script>
</head>
<body>
<div class="wrap" style="border: thin solid black; padding: 50px;border-radius: 40px 40px 40px 40px;">
	
	<img src="/wordpress/wp-content/plugins/sample_plugin/images/zealway.png" width="150" height="150" style="float: right">
	<h1>
		ZealWay Plugin <a href="https://izealiant.com" target="_blank">IZealiant</a>
	</h1>
 <br>
	<form action="/wordpress/wp-content/plugins/sample_plugin/action_page.php" method="post">
	 <label for="fname" style="padding: 10px;">First name:</label>
	<input type="text" id="fname" name="fname" value="John">
	<label for="lname" style="padding: 10px;">Surname:</label>
	 <input type="text" id="lname" name="lname" value="Doe">
	<label for="lbl_date" style="padding: 10px;">Date:</label>
	 <input type="text" id="txt_invoiceDate" name="txt_invoiceDate" value="<?php echo date('Ymd');?>">
	 <label for="lbl_invoiceNo" style="padding: 10px;">Invoice No:</label>
	 <input type="text" id="txt_invoiceNo" name="txt_invoiceNo" value="invno11110001">
	 <br><br>
	 <hr style="border: 2px solid ;">
	 <label for="billing_details" style="padding: 10px; font-size: 20px;">Billing Details:</label><br><br>
	 <label for="address_1" style="padding: 10px;">Billing Address 1:</label>
	 <input type="text" id="txt_billing_address1" name="txt_billing_address1" value="Pune – Nashik  Road">
	 <label for="address_2" style="padding: 10px;">Billing Address 2:</label>
	 <input type="text" id="txt_billing_address2" name="txt_billing_address2" value="Nashik"> <br><br>
	 <label for="address_3" style="padding: 10px;">Billing Address 3:</label>
	 <input type="text" id="txt_billing_address3" name="txt_billing_address3" value="Road">
	 <label for="lbl_billCityName" style="padding: 10px;">Billing City Name:</label>
	 <input type="text" id="txt_billingCityName" name="txt_billingCityName" value="Pune"><br><br>
	 <label for="lbl_bilingStateName" style="padding: 10px;">Billing State Name:</label>
	 <input type="text" id="txt_billingStateName" name="txt_billingStateName" value="Maharashtra"> 
	<label for="lbl_billingCountry" style="padding: 10px;">Billing Country Name:</label>
	 <input type="text" id="txt_billingCountryName" name="txt_billingCountryName" value="India"><br><br>
	 <label for="pincode" style="padding: 10px;">Pincode / Zipcode:</label>
	 <input type="text" id="txt_pincode" name="txt_pincode" value="411026"> <br><br>
	<hr style="border: 2px solid ;">

	 <label for="shiping_details" style="padding: 10px; font-size: 20px;">Shipping Details:</label><br><br>
	 <label for="ship_address_1" style="padding: 10px;">Shipping Address 1:</label>
	 <input type="text" id="txt_shipping_address1" name="txt_shipping_address1" value="Pune – Nashik  Road">
	 <label for="ship_address_2" style="padding: 10px;">Shipping Address 2:</label>
	 <input type="text" id="txt_shipping_address2" name="txt_shipping_address2" value="Nashik"> <br><br>
	 <label for="ship_address_3" style="padding: 10px;">Shipping Address 3:</label>
	 <input type="text" id="txt_shipping_address3" name="txt_shipping_address3" value="Road">
	 <label for="lbl_shipCityName" style="padding: 10px;">Shipping City Name:</label>
	 <input type="text" id="txt_shippingCityName" name="txt_shippingCityName" value="Pune"><br><br>
	 <label for="lbl_shippingStateName" style="padding: 10px;">Shipping State Name:</label>
	 <input type="text" id="txt_shippingStateName" name="txt_shippingStateName" value="Maharashtra"> 
	<label for="lbl_shippingCountry" style="padding: 10px;">Shipping Country Name:</label>
	 <input type="text" id="txt_shippingCountryName" name="txt_shippingCountryName" value="India"><br><br>
	 <label for="shipping_pincode" style="padding: 10px;">Pincode / Zipcode:</label>
	 <input type="text" id="txt_shipping_pincode" name="txt_shipping_pincode" value="411026"> <br><br>
	<hr style="border: 2px solid ;">

	<label for="contact_details" style="padding: 10px; font-size: 20px;">Contact Details:</label><br><br>
	 <label for="emailid" style="padding: 10px;">Email id:</label>
	 <input type="text" id="email_id" name="email_id" value="info@izealiant.com"><br><br>

	  <label for="phone" style="padding: 10px;">Working Phone No:</label>
	 <input type="text" id="phoneno" name="phoneno" value="9999999999">
	  <label for="lbl_homePhone" style="padding: 10px;">Home Phone No:</label>
	 <input type="text" id="txt_homePhoneNo" name="txt_homePhoneNo" value="2046465353">
	  <label for="lbl_mobilePhone" style="padding: 10px;">Mobile No:</label>
	 <input type="text" id="txt_mobileNo" name="txt_mobileNo" value="9822010345">
	 <br><br>
	 <hr style="border: 2px solid ;">
	 
	<label for="lblsubtotal">Subtotal:</label><br>
	 <input type="text" id="input_subtotal" name="input_subtotal" value="<?php echo $_POST["subtotal"]; ?>"><br><br>
	<label for="lbltotal">Total:</label><br>
	 <input type="text" id="input_total" name="input_total" value="<?php echo $_POST["total"]; ?>"><br><br>
	
	 <input type="submit" value="Submit"><br><br>
	 
		</form>
		<input type="submit" value="Rest Api Call" onclick="restAPICall()">
		
</div>

 </body>
</html>
}
?>

