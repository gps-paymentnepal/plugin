<?php

class mysql_details{

	public $servername="localhost";
  	public $username="root";
  	public $passowrd="root";
  	public $dbname="zealway_details";

public function __construct(){


}

function set_servername($servername){
	this->servername=$servername;
}
function get_servername() {
    return $this->servername;
  }

function set_username($username){
	this->username=$username;
}
function get_username(){
	return $this->username;
}

function set_password($password){
	this->password=$password;
}
function get_password(){
	return $this->password;
}

function  set_dbname($dbname){

	this->dbname=$dbname;
}

function get_dbname(){
	return $this->dbname;
}



}

?>
