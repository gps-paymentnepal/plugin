<?php

$servername='localhost';
$username='root';
$password='';
$dbname = 'zealway_details';
  // echo $dbname;
$ize_merchant_details ="CREATE TABLE ize_merchant_details (id int(11) NOT NULL AUTO_INCREMENT ,merchant_name varchar(45) DEFAULT NULL,merchant_address varchar(100) DEFAULT NULL, merchant_city varchar(30) DEFAULT NULL, merchant_state varchar(15) DEFAULT NULL, merchant_country varchar(30) DEFAULT NULL, merchant_zip varchar(10) DEFAULT NULL, merchant_mobileno varchar(15) DEFAULT NULL, merchant_telephone varchar(15) DEFAULT NULL, merchant_zealway_userid varchar(30) DEFAULT NULL, merchant_zealway_userpassword varchar(60) DEFAULT NULL,merchant_zealway_hashkey varchar(100) DEFAULT NULL,PRIMARY KEY (id))";


/*
   $conn=new mysqli($servername,
      $username,
      $password,
      $dbname
   );
 
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}*/
//createDataBase();



/* Create database */
//function createDataBase($dbname){

function createDataBase(){

    global $servername,$username,$password,$ize_merchant_details,$dbname;

    $conn = new mysqli($servername, $username, $password);
    $sql = "create database ". $dbname;
    #echo "Error: " . $sql . "<br>" . $conn->error;
    if ($conn->query($sql) === TRUE) {
        echo "Database ". $dbname . " created successfully <br>";
    }
    else
    {
        #echo "Error creating database: " . $conn->error . "<br>";
    }
    $conn->close();

    create_ize_merchant_details_table($ize_merchant_details); 

/*$sql1 = file_get_contents('zealwaydb.sql');
echo $sql1;
$qr = $conn->exec($sql1);*/

/*  if ($mysqli->multi_query($sql)) {
    $mysqli->close();
} else {
    throw new Exception ($mysqli->error);
}*/

}

/*create tables run time */
function create_ize_merchant_details_table($sql1){
  global $servername,$username,$password,$dbname;
  $conn=new mysqli($servername,
      $username,
      $password,
      $dbname
  );

  /* Check connection*/
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Error: " . $sql1 . "<br>" . $conn->error;

if ($conn->query($sql1) === TRUE) {
   # echo "Table  created successfully <br>";
}
else {
   # echo "Error creating table: " . $conn->error . "<br>";
}
$conn->close();

}


class dbconn {
  public static function deleteDatabaseDetails(){
     $conn=new mysqli('localhost',
      'root',
      '',
      'zealway_details'
  );

     $sql = "drop database zealway_details;";
     if ($conn->query($sql) === TRUE) {
        #echo "<br> Database delete successfully ! <br>";
    } else {
        #echo "Error: " . $sql . ":-" . mysqli_error($conn);
    }
    
    $conn->close();
}

}

?>