<form id="myForm" action="http://10.0.1.39:8080/ZealPos/Transaction/paymentRequest" method="post">

<?php 

//http://10.0.1.39:8080/ZealPos/Transaction/paymentRequest
$data = array(              
        'merchantID' => 'M000000014',
        'transactionType' => 'Sale',
        'merchantTxnID' => 'M0001',
        'orderRefNo' => '28860',
        'invoiceDate' => '2021-10-04',
        'invoiceNo' => 'invno11110001',
        'txnAmount' => $_POST["finalTotal"],
        'currCode' => 'INR',
        'gmtOffset' => '5.30',
        'custIPAddress' => '127.0.0.1',
        'recurFreq' => 'recurFreq',
        'recurEnd' => 'recurEnd',
        'installment' => '25000',
        'ext1' => 'ex1',
        'ext2' => 'ex2',
        'ext3' => 'ex3',
        'ext4' => 'ex4',
        'ext5' => 'ex5',
        'customerID' => 'custId00001',
        'firstName' => $_POST["first_name"],
        'lastName' => $_POST["last_name"],
        'email' => $_POST["email"],
        'phone' => '9822010345',
        'billAddLine1' => 'Pune - Nashik Road',
        'billAddLine2' => 'Nashik',
        'billAddLine3' => 'Road',
        'billCity' => 'Pune',
        'billState' => 'MH',
        'billZip' => '411026',
        'billCountryAlphaCode' => 'IND',
        'shipAddLine1' => $_POST["address"],
        'shipAddLine2' => $_POST["address2"],
        'shipAddLine3' => 'Road',
        'shipCity' => 'Pune',
        'shipState' => 'MH',
        'shipZip' => '411026',
        'shipCountryAlphaCode' => 'IND',
        'status' => '',
        'CAVV' => '',
        'ECI' => '',
        'XID' => '',
        'purchaseAmount' => '41999',
        'shoppingContext' => '88888888',
        'currValue' => '156',
        'currExponent' => '2',
        'cardType' => 'VISA',
        'cardNumber' => '',
        'nameOnCard' => 'Shekhar Jadhav',
        'expDtYr' => '',
        'expDtMon' => '',
        'cvvNum' => '123',
        'instrType' => 'Debit',
        'reserved1' => 'reserved1',
        'reserved2' => 'reserved2',
        'reserved3' => 'reserved3',
        'reserved4' => 'reserved4',
        'reserved5' => 'reserved5',
        'reserved6' => 'reserved6',
        'reserved7' => 'reserved7',
        'reserved8' => 'reserved8',
        'reserved9' => 'reserved9',
        'reserved10' => 'reserved10',
        'hashValue' => ''
    
);
$jsonStringData = json_encode($data);
//echo $jsonStringData;

$params = array(
                'merchantID' => 'M000000014',
                'merchantData' => '',
                'merchantFieldsDetails' => '',
                'JSonStringData' => $jsonStringData,                
            );

$final_chan = http_build_query($params);
//4068661000000000

$service_url = 'http://10.0.1.39:8080/ZealPos/Transaction/paymentRequest';
$curl = curl_init($service_url);
curl_setopt($curl, CURLOPT_URL, $service_url);
//curl_setopt($curl, CURLOPT_HEADER, false);
//curl_setopt($curl, CURLOPT_NOBODY, true);
//curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-type: application/x-www-form-urlencoded"));
curl_setopt($curl, CURLOPT_POST, true);
//curl_setopt ($curl, CURLOPT_REFERER, $service_url);
curl_setopt($curl, CURLOPT_POSTFIELDS, $final_chan);

//echo $curl;
$curl_response = curl_exec($curl);

//var_export($curl_response);
//exit;

//$url = curl_getinfo($curl, CURLINFO_EFFECTIVE_URL); 
//echo $url;
curl_close($curl);
/*$decoded = json_decode($curl_response);
if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
    die('error occured: ' . $decoded->response->errormessage);
}*/
//echo $decoded;
//echo htmlspecialchars_decode($decoded);
//var_export($decoded->response);
//header( 'Location: http://10.0.1.39:8080/ZealPos/Transaction/paymentRequest' );
//var_dump($curl_response);

//echo file_get_contents($curl_response)
//echo $curl_response;
?>
</form>
<script type="text/javascript">
    document.getElementById('myForm').submit();
</script>