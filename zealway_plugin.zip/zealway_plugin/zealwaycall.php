<form id="myForm" action="https://3dsjcb.izealiant.com:443/ZealPos/Transaction/paymentRequest" method="post">

<?php 


$conn=new mysqli('localhost','root','','zealway_details');
$getusername='';
$getuserpassword='';
$getuserhashkey='';
$sql = "select merchant_zealway_userid, merchant_zealway_userpassword,merchant_zealway_hashkey FROM ize_merchant_details";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        /*echo "<br> Marchant User Id:- ". $row["merchant_zealway_userid"]. " Marchant User Password:-" . $row["merchant_zealway_userpassword"] . " Marchant Hash Key:-" .$row["merchant_zealway_hashkey"] . "<br>";*/
        $getusername=test_input($row["merchant_zealway_userid"]);
        $getuserpassword=test_input($row["merchant_zealway_userpassword"]);
        $getuserhashkey=test_input($row["merchant_zealway_hashkey"]);
        
       //echo $getusername;
    }
} else {
    echo "0 results <br>";
}

$conn->close();

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

if($getusername == null || empty($getusername)){

echo "Please set zealway wordpress plugin settings first put marchant user id and password !!!";
return;
}

//echo $_POST["shipCountryAlphaCode"];
//echo $getusername;
#echo $_POST["shipZip"];


// 16-11-2021 JSON Format
/*
$data = array(              
        'merchantID' => $getusername,
        'transactionType' => $_POST["transactionType"],
        'merchantTxnID' => $_POST["merchantTxnID"],
        'orderRefNo' => $_POST["orderRefNo"],
        'invoiceDate' => '2021-10-04',
        'invoiceNo' => $_POST["invoiceNo"],
        'txnAmount' => $_POST["finalTotal"],
        'currCode' => $_POST["currCode"],
        'custIPAddress' => '127.0.0.1',
        'callBackURL' => $_POST["callBackURL"],
        'firstName' => $_POST["first_name"],
        'lastName' => $_POST["last_name"],
        'email' => $_POST["email"],
        'phone' => $_POST["phone"],
        'billAddLine1' => $_POST["billAddLine1"],
        'billAddLine2' => $_POST["billAddLine2"],
        'billAddLine3' => $_POST["billAddLine3"],
        'billCity' => $_POST["billCity"],
        'billState' => $_POST["billState"],
        'billZip' => $_POST["billZip"],
        'billCountryAlphaCode' => $_POST["billCountryAlphaCode"],
        'shipAddLine1' => $_POST["shipAddLine1"],
        'shipAddLine2' => $_POST["shipAddLine2"],
        'shipAddLine3' => $_POST["shipAddLine3"],
        'shipCity' => $_POST["shipCity"],
        'shipState' => $_POST["shipState"],
        'shipZip' => $_POST["shipZip"],
        'shipCountryAlphaCode' => $_POST["shipCountryAlphaCode"],
        'cardType' => 'VISA',
        'cardNumber' => '',
        'nameOnCard' => 'Shekhar Jadhav',
        'expDtYr' => '',
        'expDtMon' => '',
        'cvvNum' => '123',
        'instrType' => 'Debit',
        'CAVV' => '',
        'ECI' => '',
        'XID' => '',
        'purchaseAmount' => '41999',
        'shoppingContext' => '88888888',
        'currValue' => '156',
        'currExponent' => '2',
        'ext1' => 'ex1',
        'ext2' => 'ex2',
        'ext3' => 'ex3',
        'ext4' => 'ex4',
        'ext5' => 'ex5',
        'reserved1' => 'reserved1',
        'reserved2' => 'reserved2',
        'reserved3' => 'reserved3',
        'reserved4' => 'reserved4',
        'reserved5' => 'reserved5',
        'reserved6' => 'reserved6',
        'reserved7' => 'reserved7',
        'reserved8' => 'reserved8',
        'reserved9' => 'reserved9',
        'reserved10' => 'reserved10',
        'hashValue' => ''
);*/
//echo $data;

//$jsonStringData = str_replace('"', "'",json_encode($data));

$jsonStringData = str_replace('"', "'", json_encode(array(              
        'merchantID' => $getusername,
        'transactionType' => $_POST["transactionType"],
        'merchantTxnID' => $_POST["merchantTxnID"],
        'orderRefNo' => $_POST["orderRefNo"],
        'invoiceDate' => '2021-10-04',
        'invoiceNo' => $_POST["invoiceNo"],
        'txnAmount' => $_POST["finalTotal"],
        'currCode' => $_POST["currCode"],
        'custIPAddress' => '127.0.0.1',
        'callBackURL' => $_POST["callBackURL"],
        'firstName' => $_POST["first_name"],
        'lastName' => $_POST["last_name"],
        'email' => $_POST["email"],
        'phone' => $_POST["phone"],
        'billAddLine1' => $_POST["billAddLine1"],
        'billAddLine2' => $_POST["billAddLine2"],
        'billAddLine3' => $_POST["billAddLine3"],
        'billCity' => $_POST["billCity"],
        'billState' => $_POST["billState"],
        'billZip' => $_POST["billZip"],
        'billCountryAlphaCode' => $_POST["billCountryAlphaCode"],
        'shipAddLine1' => $_POST["shipAddLine1"],
        'shipAddLine2' => $_POST["shipAddLine2"],
        'shipAddLine3' => $_POST["shipAddLine3"],
        'shipCity' => $_POST["shipCity"],
        'shipState' => $_POST["shipState"],
        'shipZip' => $_POST["shipZip"],
        'shipCountryAlphaCode' => $_POST["shipCountryAlphaCode"],
        'cardType' => 'VISA',
        'cardNumber' => '',
        'nameOnCard' => 'Shekhar Jadhav',
        'expDtYr' => '',
        'expDtMon' => '',
        'cvvNum' => '123',
        'instrType' => 'Debit',
        'CAVV' => '',
        'ECI' => '',
        'XID' => '',
        'purchaseAmount' => '41999',
        'shoppingContext' => '88888888',
        'currValue' => '156',
        'currExponent' => '2',
        'ext1' => 'ex1',
        'ext2' => 'ex2',
        'ext3' => 'ex3',
        'ext4' => 'ex4',
        'ext5' => 'ex5',
        'reserved1' => 'reserved1',
        'reserved2' => 'reserved2',
        'reserved3' => 'reserved3',
        'reserved4' => 'reserved4',
        'reserved5' => 'reserved5',
        'reserved6' => 'reserved6',
        'reserved7' => 'reserved7',
        'reserved8' => 'reserved8',
        'reserved9' => 'reserved9',
        'reserved10' => 'reserved10',
        'hashValue' => ''
)));
//echo $jsonStringData;

$jsonto=str_replace('"', "'",$jsonStringData);
//echo $jsonto;

/*echo '<input type="hidden" name="merchantID" value="M000000014">';*/
echo '<input type="hidden" name="merchantID" value="' .$getusername. '">';
echo '<input type="hidden" name="merchantData" value="">';
echo '<input type="hidden" name="merchantFieldsDetails" value="">';
echo '<input type="hidden" name="JSonStringData" value="'.$jsonStringData.'">';

//echo '<input type="submit"/>';

?>
</form>
<script type="text/javascript">
 document.getElementById('myForm').submit();
</script>
