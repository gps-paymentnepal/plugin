<?php
/**
 * Zeal Pay is the simplest WordPress plugin for beginner.
 * Take this as a base plugin and modify as per your need.
 *
 * @package Zealway
 * @author Izealiant
 * @license GPL-2.0+
 * @link https:izealiant.com
 * @copyright 2021 izealiant, LLC. All rights reserved.
 *
 *            @wordpress-plugin
 *            Plugin Name: Zealway
 *            Plugin URI: https:izealiant.com
 *            Description: ZealWay Plugin.
 *            Version: 1.0
 *            Author: Izealiant
 *            Author URI: https://izealiant.com
 *            Text Domain: zeal_way
 *            Contributors: Izealiant
 
 */


defined( 'ABSPATH' ) or die( 'Hey, what are you doing here? You silly human!');

function actions_recent_bids_add_admin_page(){

    add_menu_page('Zeal Way', 'ZealWay', 'manage_options','wc-auction-reports','zealway_pluging_details','dashicons-bank', 56);   
    
/*add_submenu_page(
    'wc-auction-reports',               // parent slug
    'Recent Bids',                      // page title
    'Recent Bids',                      // menu title
    'manage_options',                   // capability
   	'wc-auction-reports',           // slug
    'acutions_customers_spendings_list' // callback
); */


add_submenu_page(
    'wc-auction-reports',               // parent slug
    'Settings',                // page title
    'Settings',                // menu title
    'manage_options',                   // capability
    'wc-acutions-customers-spendings',  // slug
    'acutions_customers_spendings_list' // callback
); 

/*add_submenu_page(
    'wc-auction-reports',          // parent slug
    'Customer Bids',               // page title
    'Customer Bids',               // menu title
    'manage_options',              // capability
    'wc-acutions-customers-bids',  // slug
    'acutions_customers_bids_list' // callback
); */ 

}

add_action('admin_menu','actions_recent_bids_add_admin_page'); 

function acutions_customers_spendings_list() {
    /*echo '<div class="wrap"><div id="icon-tools" class="icon32"></div>';
        echo '<h2>My Custom Submenu Page</h2>';
        echo '</div>';*/
        
        require_once('wc_auction_reports.php');
        
    }

    function zealway_pluging_details(){

        echo '<h2>ZealWay Pluging </h2>';

    }

    /*function sample_plugin() {*/
        class zealway_plugin {
        //private $main;

 

            
            function __construct() {
		//add_action( 'init', array( $this, 'custom_post_type' ) );
    //$this->main=new dbconn();
            }

            function activate() {
		// generated a CPT
		//$this->custom_post_type();
		// flush rewrite rules

		//include('dbconnection.php');
         //require_once( ABSPATH . 'dbconnection.php' );
       // new dbconn();
        // $load_menu=$this->main->createDataBase();
 		//createDataBase();
               $this->createDataBase_1();

               flush_rewrite_rules();
           }

           function deactivate() {
		// flush rewrite rules
              $this->dropDatabse();
              
              flush_rewrite_rules();
              
          }

	/*function custom_post_type() {
		register_post_type( 'book', ['public' => true, 'label' => 'Books'] );
	}*/


    function createDataBase_1(){

        global $servername,$username,$password,$ize_merchant_details,$dbname;

        $conn=new mysqli('localhost','root','');
        $sql = "create database zealway_details";
        echo "Error: " . $sql . "<br>" . $conn->error;
        if ($conn->query($sql) === TRUE) {
            echo "Database zealway_details created successfully <br>";
        }
        else
        {
            echo "Error creating database: " . $conn->error . "<br>";
        }
        $conn->close();

    }
    
    function dropDatabse(){
      $conn=new mysqli('localhost',
          'root',
          '',
          'zealway_details'
      );

      $sql = "drop database zealway_details;";
      if ($conn->query($sql) === TRUE) {
        echo "<br> Database delete successfully ! <br>";
    } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
    }
    
    $conn->close();
}

}


if ( class_exists( 'zealway_plugin' ) ) {
	$alecadddPlugin = new zealway_plugin();
   // $alecadddPlugin->dbcall();
}

// activation
register_activation_hook( __FILE__, array( $alecadddPlugin, 'activate' ) );

// deactivation
register_deactivation_hook( __FILE__, array( $alecadddPlugin, 'deactivate' ) );

add_shortcode('izealiant', 'zealway_plugin');
?>
