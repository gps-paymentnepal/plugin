=== Crunchify Hello World Plugin ===
Contributors: Crunchify
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=8ZF6WATLYFELQ
Tags: Hello World Plugin, Crunchify Plugins, Beginner WordPress, WordPress Plugin
Requires at least: 4.5
Tested up to: 4.7.4
Stable tag: 3.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
Create your fist plugin. Crunchify Hello World Plugin is the simplest WordPress plugin for beginner. Take this as a base plugin and modify as per your need.
 
== Description ==
 
Crunchify Hello World Plugin is the simplest WordPress plugin for beginner if you want to start creating fresh new plugin. Take this as a base plugin and modify as per your need. 
 
== Installation ==
1. Unpack the `download-package`.
2. Upload the file to the `/wp-content/plugins/` directory.
3. Activate the plugin through the `Plugins` menu in WordPress.
4. Done and Ready.
 
== Frequently Asked Questions ==
 
= How to add FAQ question =
* just add your FAQ questions here
 
== Screenshots ==
1. This is a text label for your first screenshot
2. Add more screenshot labels as new line
 
== Changelog ==
 
= 3.0 =
* Initial release