
<?php
function restapicall() {
$postdata = array(
        'name' => 'Arfan'
    );

    $url = "https://example.com/api/user/create";

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_HEADER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);

    $json_response = curl_exec($curl);
    echo $json_response ;
    $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

}
?>
<!DOCTYPE HTML>
<html>
	
	<head>
    <!--<meta http-equiv="refresh" content="5;url=http://localhost/wordpress/index.php/83-2/" /> -->
    <link href="http://localhost/wordpress/wp-content/plugins/zealway_plugin/css/fonts.css" rel="stylesheet">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<style>

.modal {
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        opacity: 0;
        visibility: hidden;
        transform: scale(1.1);
        transition: visibility 0s linear 0.25s, opacity 0.25s 0s, transform 0.25s;
    }
    .modal-content {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: white;
        padding: 1rem 1.5rem;
        width: 24rem;
        border-radius: 0.5rem;
    }
    .close-button {
        float: right;
        width: 1.5rem;
        line-height: 1.5rem;
        text-align: center;
        cursor: pointer;
        border-radius: 0.25rem;
        background-color: lightgray;
    }
    .close-button:hover {
        background-color: darkgray;
    }
    .show-modal {
        opacity: 1;
        visibility: visible;
        transform: scale(1.0);
        transition: visibility 0s linear 0s, opacity 0.25s 0s, transform 0.25s;
    }

    .button {
  border: none;
  color: white;
  background-color: #008CBA;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.main-section{
width: 460px;
position: fixed;
top: 50%;
left: 50%;
transform: translate(-50%, -50%);
}
.content-section{
background: #FFF;
border-radius: 2px;
box-shadow: 0px 0px 0px 8px rgba(0,0,0,0.1);
}
.head-section{
background: #F3F3F3;
text-align: center;
padding: 15px 0px;
border-bottom: 2px solid #CECECE;
}
.head-section h3{
margin: 0px;
color: #565656;
}
.body-section{
padding:15px 30px 30px 30px;
overflow: hidden;
}
.body-section .form-input{
width: 100%;
padding: 15px 0px;
}
.body-section .form-input input[type='text']{
width: calc(100% - 30px);
border: 1px solid #D3D3D3;
border-radius: 1px;
padding:10px 10px;
box-shadow: 0px 0px 0px 5px rgb(239,244,247);
}
.body-section .form-input input[type='checkbox']{
float: left;
}
.body-section label{
color: #565656;
padding: 1px 5px;
float: left;
}
.body-section .btn-submit{
float: right;
background: #DEEDF4;
border:1px solid #B5CBCD;
color: #56778E;
font-weight: bold;
padding:7px 20px;
border-radius: 15px;
}
.footer-section{
color: #F1F1F1;
text-align: center;
padding-top: 15px;
font-size: 12px;
}
.footer-section a{
color: #fff;
font-weight: bold;
text-decoration: none;
}
  

</style>

<script>
function pop_up(url){
window.open(url,'win2','status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=500,height=500,directories=no,location=no') 
}

</script>

<script type="text/javascript">

    function foo () {

        var name = document.getElementById("lblwelocme").textContent;
        var nnn=document.getElementById("lblwelocme").textContent + ' '+document.getElementById("lblwelocme").textContent;
    var dataPost = {
   "var": "foo",
   "welcome": name
    };
    var dataString = JSON.stringify(dataPost);
      $.ajax({
        //url:"/wordpress/wp-content/plugins/sample_plugin/restPost.php", //the page containing php script
        url:"/wordpress/wp-content/plugins/zealway_plugin/NICRestAPI.php", //the page containing php script
        type: "POST", //request type
        data: {myData: dataString},
        success:function(result){
         alert(result);
       }
     });
 }
</script>

  </head> 
<body>
 <div class="wrap" style="border: thin solid black; padding: 10px;">

<label for="lblfname" id="lblwelocme" name="lblwelocme">Welcome : <?php echo $_POST["fname"];  ?></label><br>
<label for="lblemail">Your email address is: <?php echo $_POST["email_id"]; ?></label><br>
<label for="lblphone">Mobile No: <?php echo $_POST["phoneno"]; ?></label><br>
<label for="lblcountry">Country Name: <?php echo $_POST["countryname"]; ?></label><br><br>
<label for="lblsubtotal">Subtotal : <?php echo $_POST["input_subtotal"]; ?></label><br><br>
<label for="lbltotal">Total : <?php echo $_POST["input_total"]; ?></label><br><br>
	
</div>

<button class="trigger button">Order Conform</button>

<td>
    <a href="update_users.php?person_id=<?php echo $row['person_id']; ?>" onclick="pop_up(this);">EDIT</a>
</td>

<td>
    <button type="button" class="btn-submit" id="btn_restapi" onclick="foo()">rest api</button>
</td>

<div class="modal">
    <div class="modal-content">
        <!--<span class="close-button">×</span> -->
        
        <div class="main-section">
					<div class="content-section">
						<div class="head-section">
							<div class="row">
								<img src="/wordpress/wp-content/plugins/zealway_plugin/images/zealway.png" width="100" height="50" >
							</div>
							
							</div>
							<div class="body-section">
									<h3>Login</h3>
									<form  action="/wordpress/index.php/83-2/" method="post">
										<div class="form-input">
										<input type="text" name="" placeholder="Username or Email">
										</div>
										<div class="form-input">
										<input type="text" name="" placeholder="Password">
										</div>
										<div class="form-input">
										<!--<input type="checkbox" name=""> <label>Remember me on this computer</label> -->
										<button type="submit" class="btn-submit">Login</button>
										
										</div>
										</form>

										<button type="rest api" class="btn-submit">rest api</button>
										</div>
										</div>
					<div class="footer-section">
			<!--	<a href="">Forgot your password?</a> <span>Click here to reset it.</span>-->
				</div>
				</div>
    </div>
</div>

<script type="text/javascript">

const modal = document.querySelector(".modal");
const trigger = document.querySelector(".trigger");
//const closeButton = document.querySelector(".close-button");

function toggleModal() {
    modal.classList.toggle("show-modal");
}
trigger.addEventListener("click", toggleModal);
//closeButton.addEventListener("click", toggleModal);
//window.addEventListener("click", windowOnClick);

function windowOnClick(event) {
    if (event.target === modal) {
        toggleModal();
    }
}

trigger.addEventListener("click", toggleModal);
//closeButton.addEventListener("click", toggleModal);
//window.addEventListener("click", windowOnClick);

    </script>



</body>
</html>
