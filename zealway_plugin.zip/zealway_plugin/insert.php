<?php
//include "dbconnection.php";


  /*  $servername='localhost';
    $username='root';
    $password='';
    $dbname = 'zealway_details';
    //echo $dbname;
  // $connect=mysqli_connect($servername,$username,$password,$dbname);
   $conn=new mysqli($servername,
      $username,
      $password,
      $dbname
   );
 
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}*/

if (isset($_POST['submit'])) {

   include('dbconnection.php');
   createDataBase();
   deleteTableData();
   insertMerchantDetails();
   selectTabaleDetails();
  # echo "Marchenat Details save successfully!!!";
 // $classA = new dbconn();
  //$classA->createDataBase();

}   


function insertMerchantDetails(){

   $conn=new mysqli('localhost',
      'root',
      '',
      'zealway_details'
   );
   $zealwayUserId = $_POST['zealwayuserid'];
   $zealwayPassword = $_POST['zealwaypassword'];
   $zealwayHashKey = $_POST['hashKey'];
   $sql = "insert into ize_merchant_details (merchant_zealway_userid, merchant_zealway_userpassword, merchant_zealway_hashkey) VALUES ('$zealwayUserId','$zealwayPassword','$zealwayHashKey')";
   #echo  $sql;
     //echo $conn;
   if ($conn->query($sql) === TRUE) {
   # echo "<br> New record has been added successfully ! <br>";
      echo "Marchenat Details save successfully!!!";
 } else {
    #echo "Error: " . $sql . ":-" . mysqli_error($conn);
 }
 mysqli_close($conn);

}


function deleteTableData(){

   $conn=new mysqli('localhost',
      'root',
      '',
      'zealway_details'
   );

     //$sql = "delete from ize_merchant_details";
   $sql="truncate table ize_merchant_details;";
   #echo  $sql;
     //echo $conn;
   if ($conn->query($sql) === TRUE) {
    #echo "<br> Table Data delete successfully ! <br>";
 } else {
   # echo "Error: " . $sql . ":-" . mysqli_error($conn);
 }
 mysqli_close($conn);

}


function selectTabaleDetails(){
   $conn=new mysqli('localhost',
      'root',
      '',
      'zealway_details'
   );

   $sql = "select merchant_zealway_userid, merchant_zealway_userpassword,merchant_zealway_hashkey FROM ize_merchant_details";
   $result = $conn->query($sql);

   if ($result->num_rows > 0) {
    // output data of each row
     while($row = $result->fetch_assoc()) {
      # echo "<br> Marchant User Id:- ". $row["merchant_zealway_userid"]. " Marchant User Password:-" . $row["merchant_zealway_userpassword"] . " Marchant Hash Key:-" .$row["merchant_zealway_hashkey"] . "<br>";
    }
 } else {
  echo "0 results";
}

$conn->close();
}

function deleteDatabaseDetails(){
   $conn=new mysqli('localhost',
      'root',
      '',
      'zealway_details'
   );

   $sql = "drop database zealway_details;";
   if ($conn->query($sql) === TRUE) {
  #  echo "<br> Database delete successfully ! <br>";
 } else {
   # echo "Error: " . $sql . ":-" . mysqli_error($conn);
 }
 
 $conn->close();
}

/*
if(isset($_POST['submit']))
{    
   echo $_POST['merchant_name'];
     $merchantName = $_POST['merchant_name'];
     $email = $_POST['email'];
     $mobile = $_POST['mobileno'];
     $sql = "INSERT INTO `ize_merchant_details`(`merchant_name`, `merchant_address`, `merchant_mobileno`) VALUES ('$merchantName','$email','$mobile')";
     echo  $sql;
     //echo $conn;
     if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
  }*/
  ?>
