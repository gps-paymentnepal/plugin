<!DOCTYPE html>
<html>
<head>   
</head>
<body>
<form class="needs-validation" method="POST" action="/wordpress/wp-content/plugins/zealway_plugin/zealwaycall.php"> 
           
           <div class="row">
                <label for="transaction_Type">Transaction_Type</label>
                <input type="text" class="form-control" id="transaction_Type" name="transactionType" placeholder="Transaction_Type">

                <label for="merchant_TxnID">Merchant_TxnID</label>
                <input type="text" class="form-control" id="merchant_TxnID" name="merchantTxnID" placeholder="MerchantTxnID">
                <label for="OrderRefNo">OrderRefNo</label>
                <input type="text" class="form-control" id="Order_RefNo" name="orderRefNo" placeholder="Order_RefNo">

                 <label for="InvoiceNo">InvoiceNo</label>
                <input type="text" class="form-control" id="InvoiceNo" name="invoiceNo" placeholder="Invoice No">

                 <label for="FinalTotal">FinalTotal</label>
                <input type="text" class="form-control" id="final_Total" name="finalTotal" placeholder="FinalTotal">

                 <label for="Curr_Code">CurrCode</label>
                <input type="text" class="form-control" id="curr_Code" name="currCode" placeholder="INR">

                <label for="CallBackURL">CallBackURL</label>
                <input type="text" class="form-control" id="callBack_URL" name="callBackURL" placeholder="CallBack_URL">

                <label for="first_name">FirstName</label>
                <input type="text" class="form-control" id="firstName" name="first_name" placeholder="firstName">

                <label for="lastName">lastName</label>
                <input type="text" class="form-control" id="lastName" name="last_name" placeholder="lastName">

           </div>
               <div class="row">
                <label for="Email">Email</label>
                <input type="text" class="form-control" id="email_id" name="email" placeholder="email_id">

                <label for="Phone">Phone</label>
                <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone">

                <label for="billAdd_Line1">BillAddLine1</label>
                <input type="text" class="form-control" id="billAdd_Line1" name="billAddLine1" placeholder="billAdd_Line1">

                 <label for="billAdd_Line2">BillAddLine2</label>
                <input type="text" class="form-control" id="billAdd_Line2" name="billAddLine2" placeholder="billAdd_Line2">

                 <label for="BillAddLine3">BillAddLine3</label>
                <input type="text" class="form-control" id="billAdd_Line3" name="billAddLine3" placeholder="billAdd_Line3">

                 <label for="BillCity">BillCity</label>
                <input type="text" class="form-control" id="bill_City" name="billCity" placeholder="bill_City">

                <label for="BillState">BillState</label>
                <input type="text" class="form-control" id="bill_State" name="billState" placeholder="bill_State">

                <label for="BillZip">bill_Zip</label>
                <input type="text" class="form-control" id="bill_Zip" name="billZip" placeholder="Bill_Zip">

                <label for="BillCountryAlphaCode">BillCountryAlphaCode</label>
                <input type="text" class="form-control" id="billCountry_AlphaCode" name="billCountryAlphaCode" placeholder="billCountry_AlphaCode">

           </div>


           <div class="row">
                <label for="ShipAddLine1">ShipAddLine1</label>
                <input type="text" class="form-control" id="ShipAdd_Line1" name="shipAddLine1" placeholder="ShipAdd_Line1">

                <label for="ShipAdd_Line2">ShipAddLine2</label>
                <input type="text" class="form-control" id="shipAdd_Line2" name="shipAddLine2" placeholder="shipAdd_Line2">

                <label for="shipAddLine3">ShipAddLine3</label>
                <input type="text" class="form-control" id="shipAdd_Line3" name="shipAddLine3" placeholder="shipAdd_Line3">

                 <label for="ship_City">ship_City</label>
                <input type="text" class="form-control" id="ship_City" name="shipCity" placeholder="ship_City">

                 <label for="ship_State">ship_State</label>
                <input type="text" class="form-control" id="ship_State" name="shipState" placeholder="ship_State">

                 <label for="ship_Zip">ship_Zip</label>
                <input type="text" class="form-control" id="ship_Zip" name="shipZip" placeholder="ship_Zip">

                <label for="shipCountry_AlphaCode">shipCountry_AlphaCode</label>
                <input type="text" class="form-control" id="shipCountry_AlphaCode" name="shipCountryAlphaCode" placeholder="shipCountry_AlphaCode">
           </div>
           
            <hr class="mb-4">
            <button class="btn btn-primary btn-lg btn-block" type="submit" name="submit" value="submit" >Continue to checkout</button>
          </form>

        </body>
        </html>


<!--
VARIABLE List
 name="transactionType"
name="merchantTxnID"
name="orderRefNo"
name="invoiceNo"
name="finalTotal"
name="currCode"
name="callBackURL"
name="first_name"
name="last_name"
name="email"
name="phone"
name="billAddLine1"
name="billAddLine2"
name="billAddLine3"
name="billCity"
name="billState"
name="billZip"
name="billCountryAlphaCode"
name="shipAddLine1"
name="shipAddLine2"
name="shipAddLine3"
name="shipCity"
name="shipState"
name="shipZip"
name="shipCountryAlphaCode" -->