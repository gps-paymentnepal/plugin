<!DOCTYPE html>
<html lang="en">
<head>
   <link rel="stylesheet" href="./wordpress/wp-content/plugins/zealway_plugin/css/popup.css"/>
   <link rel="stylesheet1" href="./wordpress/wp-content/plugins/zealway_plugin/js/popup_call.js"/>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

.button {
  border: none;
  color: white;
background-color: #008CBA;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}


.modal {
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        opacity: 0;
        visibility: hidden;
        transform: scale(1.1);
        transition: visibility 0s linear 0.25s, opacity 0.25s 0s, transform 0.25s;
    }
    .modal-content {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: white;
        padding: 1rem 1.5rem;
        width: 24rem;
        border-radius: 0.5rem;
    }
    .close-button {
        float: right;
        width: 1.5rem;
        line-height: 1.5rem;
        text-align: center;
        cursor: pointer;
        border-radius: 0.25rem;
        background-color: lightgray;
    }
    .close-button:hover {
        background-color: darkgray;
    }
    .show-modal {
        opacity: 1;
        visibility: visible;
        transform: scale(1.0);
        transition: visibility 0s linear 0s, opacity 0.25s 0s, transform 0.25s;
    }
</style>


</head>
<body>

<form action="/wordpress/index.php/83-2/" method="post">
<table>
<thead>
<tr>
<th>Image</th>
<th>Item Name</th>
<th>Price</th>
<th>Quantity</th>
<th>Subtotal</th>
</tr>
</thead>
<tbody>
<tr>
<th><img src="/wordpress/wp-content/plugins/zealway_plugin/images/pen1.jpg" width="60" height="80" style="vertical-align:middle"></th>
<th>Pen</th>
<th>10</th>
<th>2</th>
<th>20</th>
</tr>
<tr>
<th><img src="/wordpress/wp-content/plugins/zealway_plugin/images/colorbox.jpg" width="60" height="80" style="vertical-align:middle"></th>
<th>Color Box</th>
<th>30</th>
<th>2</th>
<th>60</th>
</tr>
<tr>
<th><img src="/wordpress/wp-content/plugins/zealway_plugin/images/schoolbag.jpg" width="60" height="80" style="vertical-align:middle"></th>
<th>School Bag</th>
<th>300</th>
<th>1</th>
<th>300</th>
</tr>
</tbody>
</table>

<p><label for="subtoal">Subtotal</label> <input name="subtotal" type="text" id="subtotal" value="380"></p>

<p><label for="total">Total</label> <input name="total" type="text" value="380" id="total"></p>

<input type="submit" class="button">

</form>

<button class="trigger">Click here to trigger the modal!</button>
<div class="modal">
    <div class="modal-content">
        <span class="close-button">×</span>
        <h1>Hello, I am a modal!</h1>
    </div>
</div>

<script type="text/javascript">
  
  const modal = document.querySelector(".modal");
const trigger = document.querySelector(".trigger");
const closeButton = document.querySelector(".close-button");

function toggleModal() {
    modal.classList.toggle("show-modal");
}
trigger.addEventListener("click", toggleModal);
closeButton.addEventListener("click", toggleModal);
window.addEventListener("click", windowOnClick);

function windowOnClick(event) {
    if (event.target === modal) {
        toggleModal();
    }
}

trigger.addEventListener("click", toggleModal);
closeButton.addEventListener("click", toggleModal);
window.addEventListener("click", windowOnClick);

</script>

</body>
</html>