<?php 

$obj = json_decode($_POST["myData"]);

//echo $obj->var
//next example will insert new conversation
$service_url = 'https://example.com/api/conversations';
//$service_url = 'http://<domain name>/ZealWay/processMerchantRequest';
//$service_url='http://10.0.1.18/ZealWay/processMerchantRequest';
$curl = curl_init($service_url);

/*$curl_post_data = array(
       'message' => 'test message',
       'useridentifier' => 'agent@example.com',
       'department' => 'departmentId001',
      'subject' => 'My first conversation',
      'recipient' => 'recipient@example.com',
       'apikey' => 'key001'
); */

$curl_post_data = array(
  'acquirerMerchantID'=> 'M000000014',
  'invoiceDate'=> $obj->invDate,
  'invoiceNo'=> $obj->invNo,
  'orderDescription'=> 'invno11110001',
  'purchaseAmount'=> $obj->totalAmount,
  'purchaseCurrency'=> 'MMK',
  'currExponent'=> '2',
  'timestamp'=> '1535166225',
  'preferchannel'=> 'KBZPay',
  'appid'=> 'Kp12312b84664d44679693855d82a291',
  'notify_url'=> 'https=>//xxxxxx',
  'trade_type'=> 'PAY_BY_QRCODE',
  'timeout_express'=> $_POST["myData"],
  'operator_id'=> '',
  'store_id'=> '',
  'terminal_id'=> '',
  'customerName'=> $obj->customer_name,
  'addrMatch'=> 'Yes',
  'billAddrCity '=> $obj->billAddrCity,
  'billAddrCountry'=> $obj->billAddrCountry,
  'billAddrLine1'=> $obj->billAddr1,
  'billAddrLine2'=> $obj->billAddr2,
  'billAddrLine3'=> $obj->billAddr3,
  'billZip'=> $obj->billZip,
  'billAddrState'=> $obj->billAddrState,
  'shipAddrCity'=> $obj->shipCity,
  'shipAddrCountry'=> $obj->shipCountry,
  'shipAddrLine1'=> $obj->shipAddr1,
  'shipAddrLine2'=> $obj->shipAddr2,
  'shipAddrLine3'=> $obj->shipAddr3,
  'shipZip'=> $obj->shipZip,
  'shipAddrState'=> $obj->shipState,
  'workPhone'=> $obj->customerWorkingNo,
  'email'=> $obj->customerEmail,
  'homePhone'=> $obj->customerHomeNo,
  'mobilePhone'=> $obj->customerMobileNo,
  'hashValue'=> 'D31E0D55A470F4EBEBE2C1FAEE954A270D86A43F88'
); 

//echo $curl_post_data;



curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_post_data);
$curl_response = curl_exec($curl);
if ($curl_response === false) {
    $info = curl_getinfo($curl);
    curl_close($curl);
    die('error occured during curl exec. Additioanl info: ' . var_export($info));
}
curl_close($curl);
$decoded = json_decode($curl_response);
if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
    die('error occured: ' . $decoded->response->errormessage);
}
//echo 'response ok!';
//var_export($decoded->response);

//$obj = json_decode($_POST["myData"]);

//echo $obj->var

//print_r ($_POST);

$data_string = json_encode($curl_post_data);
echo $data_string;


//$mysqlDeetails=new mysql_details();
//echo $mysqlDeetails->servername;
?>